 package com.example.heatscale;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

 public class SecondActivity extends AppCompatActivity {

     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_second);
         Button button = findViewById(R.id.button); // Use Button instead of View
         TextView textView5 = findViewById(R.id.textView5);
         EditText editText = findViewById(R.id.editTextNumberDecimal); // Make sure the input is of type numberDecimal

         button.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 String s = editText.getText().toString();
                 double celsius = Double.parseDouble(s);
                 double fahrenheit = (celsius * 9 / 5) + 32;
                 String formattedFahrenheit = String.format("%.2f", fahrenheit);
                 textView5.setText("The corresponding temperature in Fahrenheit is " + formattedFahrenheit + " °F");
             }
         });
     }
 }