package com.example.heatscale;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ThirdActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        Button button3 = findViewById(R.id.button); // Use Button instead of View
        TextView textView8 = findViewById(R.id.textView5);
        EditText editText = findViewById(R.id.editTextNumberDecimal); // Make sure the input is of type numberDecimal

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s = editText.getText().toString();
                double fahrenheit = Double.parseDouble(s); // Use Double.parseDouble to handle decimal values
                double celsius = (fahrenheit - 32) * 5 / 9;
                String formattedCelsius = String.format("%.2f", celsius);
                textView8.setText("The corresponding temperature in Celsius is " + formattedCelsius + " °C");
            }
        });
    }
}
