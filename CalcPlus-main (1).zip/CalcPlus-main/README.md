# CalcPlus


###This is a new Calculator
<img width="332" alt="Screenshot 2023-10-25 at 10 48 14 PM" src="https://github.com/YakshVerma101/CalcPlus/assets/123888057/27d6b074-9cfe-4a44-9f1e-520e1eb9fe4c">