package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView display;
    String currentInput = "";
    double num1 = 0;
    double num2 = 0;
    String operator = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        display = findViewById(R.id.display);

        // Replace Button with ImageView
        ImageView zero = findViewById(R.id.zero);
        ImageView one = findViewById(R.id.one);
        ImageView two = findViewById(R.id.two); // Change this to the correct ImageView ID
        ImageView three = findViewById(R.id.three); // Change this to the correct ImageView ID
        ImageView four = findViewById(R.id.four); // Change this to the correct ImageView ID
        ImageView five = findViewById(R.id.five); // Change this to the correct ImageView ID
        ImageView six = findViewById(R.id.six); // Change this to the correct ImageView ID
        ImageView seven = findViewById(R.id.seven); // Change this to the correct ImageView ID
        ImageView eight = findViewById(R.id.eight); // Change this to the correct ImageView ID
        ImageView nine = findViewById(R.id.nine); // Change this to the correct ImageView ID

        ImageView plus = findViewById(R.id.plus);
        ImageView minus = findViewById(R.id.minus);
        ImageView divide = findViewById(R.id.divide);
        ImageView multiply = findViewById(R.id.multiply);
        ImageView dot = findViewById(R.id.dot);
        ImageView equal = findViewById(R.id.equal);
        ImageView clear = findViewById(R.id.clear);

        zero.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                updateDisplay("0");
            }
        });

        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("1");
            }
        });

        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("2");
            }
        });

        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("3");
            }
        });

        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("4");
            }
        });

        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("5");
            }
        });

        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("6");
            }
        });

        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("7");
            }
        });

        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("8");
            }
        });

        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("9");
            }
        });

        plus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                updateDisplay("+");
            }
        });

        minus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                updateDisplay("-");
            }
        });

        multiply.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                updateDisplay("×"); // Use "×" for multiplication
            }
        });

        divide.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                updateDisplay("/");
            }
        });

        dot.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                updateDisplay(".");
            }
        });

        equal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (!currentInput.isEmpty() && !operator.isEmpty()) {
                    num2 = Double.parseDouble(currentInput);
                    double result = performOperation(num1, num2, operator);
                    display.setText(String.valueOf(result));
                    currentInput = String.valueOf(result);
                    operator = "";
                }
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                display.setText(""); // Clear the display
                currentInput = "";
                num1 = 0;
                num2 = 0;
                operator = "";
            }
        });
    }

    private double performOperation(double num1, double num2, String operator) {
        switch (operator) {
            case "+":
                return num1 + num2;
            case "-":
                return num1 - num2;
            case "×": // Use "×" for multiplication
                return num1 * num2;
            case "/":
                if (num2 != 0) {
                    return num1 / num2;
                } else {
                    // Handle division by zero error
                    return Double.POSITIVE_INFINITY;
                }
            default:
                return num2;
        }
    }

    private void updateDisplay(String text) {
        if (text.matches("[0-9.]")) {
            currentInput += text;
        } else if (text.matches("[+\\-×/]")) {
            if (!currentInput.isEmpty()) {
                if (operator.isEmpty()) {
                    num1 = Double.parseDouble(currentInput);
                    currentInput = "";
                    operator = text;
                } else {
                    // Handle case where an operator is clicked right after another operator
                    // Update the operator without affecting num1 or currentInput
                    operator = text;
                }
            }
        }
        display.setText(currentInput);
    }
}

